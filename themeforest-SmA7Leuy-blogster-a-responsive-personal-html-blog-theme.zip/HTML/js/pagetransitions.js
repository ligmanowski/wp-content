var PageTransitions = (function() {

	var $main = $( '.display-pages-post' ),
		$pages = $main.children( 'div.page' ),
		pagesCount = $pages.length,
		current = 0,
		isAnimating = false,
		endCurrPage = false,
		endNextPage = false,
        isAnimating1 = false,
		endCurrPage1 = false,
		endNextPage1 = false,
		animEndEventNames = {
			'WebkitAnimation' : 'webkitAnimationEnd',
			'OAnimation' : 'oAnimationEnd',
			'msAnimation' : 'MSAnimationEnd',
			'animation' : 'animationend'
		},
		// animation end event name
		animEndEventName = animEndEventNames[ Modernizr.prefixed( 'animation' ) ],
		// support css animations
		support = Modernizr.cssanimations;
	
	function init() {

		$pages.each( function() {
			var $page = $( this );
			$page.attr( 'data-originalClassList', $page.attr( 'class' ) );
		} );
        nextPage($($pages[0]));
		
	}

	function nextPage($nextPage) {
		

		if( isAnimating ) {
			return false;
		}

		isAnimating = true;
        
		var $currPage = $("#post-view .current-page");
        if ($currPage.length>0) {
        //if ($nextPage.attr("last-scroll-pos")!= undefined) {
        //    jQuery("#post-container").animate({ scrollTop: $nextPage.attr("last-scroll-pos") }, 'slow', 'swing');
        //}
        
            $nextPage.addClass( 'current-page' );
            var outClass = '', inClass = '';
		    		outClass = 'pt-page-rotatePushBottom';
		    		inClass = 'pt-page-rotatePullTop pt-page-delay180';
		    	

		    $currPage.addClass( outClass ).on( animEndEventName, function() {
		    	$currPage.off( animEndEventName );
		    	endCurrPage = true;
		    	if( endNextPage ) {
		    		onEndAnimation( $currPage, $nextPage );
		    	}
		    } );

		    $nextPage.addClass( inClass ).on( animEndEventName, function() {
		    	$nextPage.off( animEndEventName );
		    	endNextPage = true;
		    	if( endCurrPage ) {
		    		onEndAnimation( $currPage, $nextPage );
		    	}
                $nextPage.height("auto");
                jQuery(".page").height($nextPage.height());

		    } );

		    if( !support ) {
		    	onEndAnimation( $currPage, $nextPage );
		    }
        }
        else{
            $nextPage.addClass( 'current-page' );
            var outClass = '', inClass = '';

		    
		    		outClass = 'pt-page-rotatePushBottom';
		    		inClass = 'pt-page-rotatePullTop pt-page-delay180';
		    	

		    $nextPage.addClass( inClass ).on( animEndEventName, function() {
		    	$nextPage.off( animEndEventName );
		    	endNextPage = true;
                onEndAnimation( $currPage, $nextPage );
		    } );

		    if( !support ) {
		    	onEndAnimation( $currPage, $nextPage );
		    }
        }
		

		

	}
    function PageOuter($nextPage,$currPage,clsname) {
		
		    $nextPage.addClass( clsname);
            var outClass = '', inClass = '';

		    
		    		outClass = 'pt-page-rotatePushBottom';
		    		inClass = 'pt-page-rotatePullTop pt-page-delay180';
		    	

		    $currPage.addClass( outClass ).on( animEndEventName, function() {

		    	$currPage.off( animEndEventName );
                
		    	endCurrPage1 = true;
                $currPage.height(0);
		    	if( endNextPage1 ) {
		    		onEndAnimation1( $currPage, $nextPage,clsname );
		    	}
		    } );

		    $nextPage.addClass( inClass ).on( animEndEventName, function() {
		    	$nextPage.off( animEndEventName );
		    	endNextPage1 = true;
		    	if( endCurrPage1 ) {
		    		onEndAnimation1( $currPage, $nextPage ,clsname);
		    	}
		    } );

		    if( !support ) {
		    	onEndAnimation1( $currPage, $nextPage ,clsname);
		    }
	}
	function PageOuter2($nextPage,$currPage,clsname) {
			$currPage.removeClass('pt-page-rotatePushBottom');
		    $nextPage.addClass( clsname);
			var outClass = '', inClass = '';
				outClass = 'pt-page-rotatePushBottom';
		    	inClass = 'pt-page-rotatePullTop pt-page-delay180';

		    $currPage.addClass( outClass ).on( animEndEventName, function() {
		    	$currPage.off( animEndEventName );
		    	endCurrPage1 = true;
		    	if( endNextPage1 ) {
		    		onEndAnimation2( $currPage, $nextPage,clsname );
		    	}
		    });
		    $nextPage.addClass( inClass ).on( animEndEventName, function() {
		    	$nextPage.off( animEndEventName );
		    	endNextPage1 = true;
		    	if( endCurrPage1 ) {
		    		onEndAnimation2( $currPage, $nextPage ,clsname);
		    	}
		    });
		    if( !support ) {
		    	onEndAnimation2( $currPage, $nextPage ,clsname);
		    }
	}
	function onEndAnimation( $outpage, $inpage ) {
		endCurrPage = false;
		endNextPage = false;
		resetPage( $outpage, $inpage );
		isAnimating = false;
	}
    function onEndAnimation1( $outpage, $inpage,clsname ) {
		endCurrPage1 = false;
		endNextPage1 = false;
		resetPage1( $outpage, $inpage,clsname );
		isAnimating1 = false;
	}
	function onEndAnimation2( $outpage, $inpage,clsname ) {
		endCurrPage1 = false;
		endNextPage1 = false;
		resetPage2( $outpage, $inpage,clsname );
		isAnimating1 = false;
	}
	function resetPage( $outpage, $inpage ) {
		$outpage.attr( 'class', $outpage.attr( 'data-originalClassList' ) );
		$inpage.attr( 'class', $inpage.attr( 'data-originalClassList' ) + ' current-page' );
	}
    function resetPage1( $outpage, $inpage,clsname ) {
		$outpage.attr( 'class', $outpage.attr( 'data-originalClassList' ) );
		$inpage.attr( 'class', $inpage.attr( 'data-originalClassList' ) + ' '+clsname );
        $inpage.attr('style',"");
        $outpage.attr('style',"");
	}
	function resetPage2( $outpage, $inpage,clsname ) {
		$outpage.removeClass(clsname);
		//$outpage.attr( 'class', $outpage.attr( 'data-originalClassList' ) );
		$inpage.attr( 'class', $inpage.attr( 'data-originalClassList' ) + ' '+clsname );
        $inpage.attr('style',"");
        $outpage.attr('style',"");

	}
	init();

	return { 
		init : init,
		nextPage : nextPage,
        PageOuter : PageOuter,
		PageOuter2 : PageOuter2,
	};

})();