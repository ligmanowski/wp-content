"use strict";

function GetHeightCss() {
    var h = window.innerHeight
|| document.documentElement.clientHeight
|| document.body.clientHeight;

    var w = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;
    var css = "";
    var fullh = 0;
    var largeh = 0;
    var smallh = 0;
    var thirdh = 0;

    var guttersize = 120;
    if (w < 1200) { guttersize = 60; }
    if (w > 1199) {

        fullh = parseInt((h - guttersize), 10);
        if ((fullh % 2) != 0) {
            fullh = fullh - 1;
        }
        largeh = parseInt(fullh / 2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        fullh = largeh * 2;
        thirdh = largeh * 1.5;
        smallh = parseInt((largeh / 2), 10);
    }
    else if (w < 1200 && w > (h * 1.5) && w > 767) {

        fullh = parseInt((h - guttersize), 10);
        if ((fullh % 2) != 0) {
            fullh = fullh - 1;
        }
        largeh = parseInt(fullh / 2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        fullh = largeh * 2;
        largeh = parseInt(fullh / 1.2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        thirdh = largeh * 1.5;
        smallh = largeh;
    }
    else if (w < 1200 && w > 767) {

        fullh = parseInt((h - guttersize), 10);
        if ((fullh % 2) != 0) {
            fullh = fullh - 1;
        }

        largeh = parseInt(fullh / 2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        fullh = largeh * 2;
        thirdh = largeh * 1.5;
        smallh = parseInt((largeh / 2), 10);

    }
    else if (w < 768 && w > (h * 1.5)) {

        fullh = parseInt((h - guttersize), 10);
        if ((fullh % 2) != 0) {
            fullh = fullh - 1;
        }
        largeh = parseInt(fullh / 2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        fullh = largeh * 2;
        largeh = parseInt(fullh / 1.2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        thirdh = largeh * 1.5;
        smallh = largeh;
    }
    else if (w < 768) {

        fullh = parseInt((h - guttersize), 10);
        if ((fullh % 2) != 0) {
            fullh = fullh - 1;
        }

        largeh = parseInt(fullh / 2, 10);
        if ((largeh % 2) != 0) {
            largeh = largeh - 1;
        }
        fullh = largeh * 2;
        thirdh = largeh * 1.5;
        smallh = largeh;

    }

    css = '.height-one-half { height: ' + largeh + 'px;}.height-one-third { height: ' + thirdh + 'px;}' + '.height-one-fourth { height: ' + smallh + 'px;}.height-one-one { height: ' + fullh + 'px;}';
    var cssEle = document.getElementById('heightStyle');

    if (cssEle == null) {
        var head = document.head || document.getElementsByTagName('head')[0],
            style = document.createElement('style');
        style.type = 'text/css';
        style.setAttribute("id", "heightStyle");
        if (style.styleSheet) {
            style.styleSheet.cssText = css;
        } else {
            style.appendChild(document.createTextNode(css));

        }
        head.appendChild(style);
    }
    else {
        cssEle.innerHTML = css;
        RemoveGap();
        setMobileMenuSocial();
    }
}
GetHeightCss();
jQuery(document).ready(function ($) {


    $('#post-container').scrollbar({ duration: 0 });
    var isLateralNavAnimating = false;

    //open/close lateral navigation
    $('.cd-nav-trigger,.cd-primary-nav li a').on('click', function (event) {
        event.preventDefault();
        //stop if nav animation is running 
        if (!isLateralNavAnimating) {
            if ($(this).parents('.csstransitions').length > 0) isLateralNavAnimating = true;
            $('body').toggleClass('navigation-is-open');
            $('.cd-navigation-wrapper').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function () {
                //animation is over
                isLateralNavAnimating = false;
            });
        }
    });
    $('.close-post').click(function () { ClosePost(); });
    var counter = 0;
    $('.image-background').each(function () {
        var id = "bk_image" + counter;
        $(this).attr("id", id);
        $("#" + id).parallax("50%", -0.2);
        counter++;
    });

    UpdateTriggerEvents();

    $(".twitter-feeds").click(function () {
        if ($(".twitter-feeds").hasClass("open")) {
            PageTransitions.PageOuter2($(".postcontainer-1,.postcontainer-2"), $(".twittercontainer-1,.twittercontainer-2"), 'socials-news-current');
            //PageTransitions.PageOuter($(".postcontainer-2"), $(".twittercontainer-2"), 'socials-news-current');
        }
        else {
            PageTransitions.PageOuter2($(".twittercontainer-1,.twittercontainer-2"), $(".postcontainer-1,.postcontainer-2"), 'socials-news-current');
            //PageTransitions.PageOuter($(".twittercontainer-2"), $(".postcontainer-2"), 'socials-news-current');
        }
        $(".twitter-feeds").toggleClass("open");
    });

    $(".instagram-feeds").click(function () {
        if ($(".instagram-feeds").hasClass("open")) {
            PageTransitions.PageOuter2($(".postcontainer-insta-1,.postcontainer-insta-2"), $(".instacontainer-1,.instacontainer-2"), 'socials-news-current');
            //PageTransitions.PageOuter($(".postcontainer-insta-2"), $(".instacontainer-2"), 'socials-news-current');
        }
        else {
            PageTransitions.PageOuter2($(".instacontainer-1,.instacontainer-2"), $(".postcontainer-insta-1,.postcontainer-insta-2"), 'socials-news-current');
            //PageTransitions.PageOuter($(".instacontainer-2"), $(".postcontainer-insta-2"), 'socials-news-current');
        }
        $(".instagram-feeds").toggleClass("open");
    });
    var feed = new Instafeed({
        clientId: '65032924626349a38f9c14edf44fb946',
        limit: 2,
        target: "instacontainer-1",
        resolution: "standard_resolution",
        template: ' <li class="item"><a href="{{link}}" style="background-image:url({{image}});" target="_blank" class="no-border"></a></li>',
        after: function () {
            $('#instacontainer-1').cycle({ fx: 'fade' });
        }
    });
    feed.run();

    var feed1 = new Instafeed({
        clientId: '65032924626349a38f9c14edf44fb946',
        limit: 2,
        target: "instacontainer-2",
        resolution: "standard_resolution",
        template: ' <li class="item"><a href="{{link}}" style="background-image:url({{image}});" target="_blank" class="no-border"></a></li>',
        after: function () {
            $('#instacontainer-2').cycle({ fx: 'fade' });
        }
    });
    feed1.run();


    var config1 = {
        "id": '345170787868762112',
        "maxTweets": 10,
        "enableLinks": false,
        "showTime": false,
        "showInteraction": false,
        "showImages": false,
        "showPermalinks": false,
        "customCallback": handleTweets
    };

    twitterFetcher.fetch(config1);

    function handleTweets(tweets) {
        var x = tweets.length;
        var n = 0;
        var element = document.getElementById('twittercontainer-1');
        var element2 = document.getElementById('twittercontainer-2');
        var html = '';
        var html2 = '';
        while (n < x) {
            if ((n % 2) == 0) {
                html += '<li style="display:none;"><div class="twiter-table"><div class="twiter-table-cell"><span><i class="fa fa-twitter"></i></span>' + tweets[n] + '</li>';

            }
            else {
                html2 += '<li style="display:none;"><div class="twiter-table"><div class="twiter-table-cell"><span><i class="fa fa-twitter"></i></span>' + tweets[n] + '</li>';
            }
            n++;
        }
        element.innerHTML = html;
        element2.innerHTML = html2;
        $('#twittercontainer-1').cycle({ fx: 'fade' });
        $('#twittercontainer-2').cycle({ fx: 'fade' });
        //GetHeightCss();
    }

    window.addEventListener("orientationchange", function () {
        GetHeightCss();
    }, false);

    window.addEventListener("resize", function () {
        GetHeightCss();
    }, false);
    setTimeout(function () { RemoveGap(); setMobileMenuSocial(); }, 1000);

    $(".quick-scroll-link").click(function () {
        var scrollto = $(this).attr("scrollTo");
        if (scrollto != "") {
            scrollto = "." + scrollto;
        }
        if ($(".scroll-disabled").length > 0) {
            var scrolval = $("#post-view .current-page " + scrollto).offset().top - 60;
            if (scrolval < 0) {
                scrolval = $('.page.current-page').scrollTop() - Math.abs(scrolval);
            }
            else {
                scrolval = $('.page.current-page').scrollTop() + Math.abs(scrolval);
            }
            if (scrollto == "") {
                scrolval = 0;
            }
            $('.page.current-page').animate({ scrollTop: scrolval }, 'slow', 'swing');
        }
        else {
            var scrolval = $("#post-view .current-page " + scrollto).offset().top - 60;
            if (scrolval < 0) {
                scrolval = $('#post-container').scrollTop() - Math.abs(scrolval);
            }
            else {
                scrolval = $('#post-container').scrollTop() + Math.abs(scrolval);
            }
            $('#post-container').animate({ scrollTop: scrolval }, 'slow', 'swing');
        }


    });
    //activeQuickPostNavigation();


$(".paginate li a").click(function () {
    $(".paginate li a").removeClass("active");
    $(this).addClass("active");
    var totalpostcount = 0;
    var allPosts;
    var SelectedCat = $(this).data("type");
    var pageno = $(this).data("page");
    if (SelectedCat == "home") {
        totalpostcount = $("#hidden-post-list .post-box").length;
        allPosts = "#hidden-post-list .post-box";
    }
    else {
        totalpostcount = $("#hidden-post-list .post-box.post-" + SelectedCat).length;
        allPosts = "#hidden-post-list .post-box.post-" + SelectedCat;
    }
    var articlesAvailable = [];
    var counts = 0;
    while (counts < totalpostcount + 1) {
        articlesAvailable.push(counts++);
    }
    var linkFirst = "";
    var linklast = "";
    counts = 0;
    var items = ["lifestyle", "fashion", "travel", "music"];
    $("#post-list .post-box").each(function () {

        if (counts == 0 && SelectedCat != "home") {
            linkFirst = SelectedCat;
        }
        else if (counts == 9 && SelectedCat != "home") {
            linklast = SelectedCat;
        }
        else if (counts == 0 && SelectedCat == "home") {
            linkFirst = items[Math.floor(Math.random() * items.length)];
        }
        else if (counts == 9 && SelectedCat == "home") {
            linklast = items[Math.floor(Math.random() * items.length)];
        }

        counts++;
            var currentparent = $(this).parent();
            var ranNo = Math.floor(Math.random() * (articlesAvailable.length - 1));
            var randItem = articlesAvailable[ranNo];
            articlesAvailable.splice(ranNo, 1);
            var postToReplace = $(allPosts)[randItem];
            $(this).remove();
            $(postToReplace).clone().appendTo(currentparent);
    });

    $("#post-list .post-box:last").attr("href", "#largepost2");
    $("#post-list .post-box:first").attr("href", "#largepost");
    $($("#post-list .post-box")[1]).attr("href", "#smallpost2");
    $($("#post-list .post-box")[2]).attr("href", "#smallpost3");

    resetScrollPosition();
    UpdateTriggerEvents();
});


	$("#post-container").scroll( function(){				
		
			if($('#post-container').scrollTop() > 0){
				$("#ep-arrow").fadeOut(500);
			}
			else
			{
				$("#ep-arrow").fadeIn(500);
			}
	});		
		
	$("#post-container .display-pages-post > .page").scroll( function(){				
		
			if($('#post-container .display-pages-post  > .page').scrollTop() > 0){
				$("#ep-arrow").fadeOut(500);
			}
			else
			{
				$("#ep-arrow").fadeIn(500);
			}
	});		
	
		
});

var hoverEffect = 'undefined';
var fadeDelay = 100;
var fadeOpacity = 0.5;
if (hoverEffect === 'fadeIn') {
    $('.media-grid a').fadeTo(0, fadeOpacity).hover(
            function () {
                $(this).fadeTo(fadeDelay, 1);
            },
            function () {
                $(this).fadeTo(fadeDelay, fadeOpacity);
            }
        );
} else if (hoverEffect === 'fadeOut') {
    $('.media-grid a').hover(function () {
        $(this).fadeTo(fadeDelay, fadeOpacity);
    },
            function () {
                $(this).fadeTo(fadeDelay, 1);
            }
        );
}


function ClosePost() {
    $('.close-post').hide();
    $('.cd-nav-trigger').removeClass('hide-now');
    PageTransitions.PageOuter($("#post-list"), $("#post-view"), 'current-post-part');

    $('body').removeClass('post-open');

}

function RemoveGap() {
    $(".articles .col-xs-12.col-sm-6").attr("style", "");
    var w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    console.log($("#post-list").width());
    var pW = parseInt($("#post-list").width() / 2, 10);
    var box_mod = (pW % 2);
    if (box_mod != 0 && w > 767) {
        $(".articles .col-xs-12.col-sm-6").css("width", (pW - 1) + "px");
    }
}

function setMobileMenuSocial() {
    var h = window.innerHeight
|| document.documentElement.clientHeight
|| document.body.clientHeight;
    wh = $(".cd-navigation-wrapper").height();
    wh2 = $(".cd-half-block").height();
    if (h < (wh2 + 100 + 30) && wh2 > wh) {
        $(".cd-half-block.social-block-mobile").addClass("not-fixed");

    }
    else {
        $(".cd-half-block.social-block-mobile").removeClass("not-fixed");
    }
}

function activeQuickPostNavigation() {
    if ($("#post-view .current-page").hasClass("posttype-largepost") || $("#post-view .current-page").hasClass("posttype-smallpost")) {
        $(".post-quick-navigation").fadeIn(1000).attr("style", "display:block !important;"); ;
    }
    else {
        $(".post-quick-navigation").fadeOut(1000).attr("style", "display:none;");
    }

}



function ChangePostsByCategory(SelectedCat) {
    $(".paginate li a").removeClass("active");
    $(".paginate li a:first").addClass("active");
    $(".paginate li a").attr("data-type", SelectedCat);
    var totalpostcount = 0;
    var allPosts;
    if (SelectedCat == "home") {
        totalpostcount = $("#hidden-post-list .post-box").length;
        allPosts = "#hidden-post-list .post-box";
    }
    else {
        totalpostcount = $("#hidden-post-list .post-box.post-" + SelectedCat).length;
        allPosts = "#hidden-post-list .post-box.post-" + SelectedCat;
    }
    var articlesAvailable = [];
    var counts = 0;
    while (counts < totalpostcount + 1) {
        articlesAvailable.push(counts++);
    }
    var linkFirst = "";
    var linklast = "";
    counts = 0;
    var items = ["lifestyle", "fashion", "travel", "music"];
    $("#post-list .post-box").each(function () {

        if (counts == 0 && SelectedCat != "home") {
            linkFirst = SelectedCat;
        }
        else if (counts == 9 && SelectedCat != "home") {
            linklast = SelectedCat;
        }
        else if (counts == 0 && SelectedCat == "home") {
            linkFirst = items[Math.floor(Math.random() * items.length)];
        }
        else if (counts == 9 && SelectedCat == "home") {
            linklast = items[Math.floor(Math.random() * items.length)];
        }

        counts++;
        if (!$(this).hasClass("post-" + SelectedCat)) {
            var currentparent = $(this).parent();
            var ranNo = Math.floor(Math.random() * (articlesAvailable.length - 1));
            var randItem = articlesAvailable[ranNo];
            articlesAvailable.splice(ranNo, 1);
            var postToReplace = $(allPosts)[randItem];
            $(this).remove();
            $(postToReplace).clone().appendTo(currentparent);
        }
    });

    $("#post-list .post-box:last").attr("href", "#largepost2");
    $("#post-list .post-box:first").attr("href", "#largepost");
    $($("#post-list .post-box")[1]).attr("href", "#smallpost2");
    $($("#post-list .post-box")[2]).attr("href", "#smallpost3");

    resetScrollPosition();
    PageChange("#largepost", false);
    UpdateTriggerEvents();
}

function UpdateTriggerEvents() {
    $("a[href^='#']").click(function (event) {
        var divname = $(this).attr("href");
        if ($(divname + ".page").length > 0) {
            event.preventDefault();
            PageChange(divname,true);
        }
    });
    $(".scroll-top").click(ScrollToTop);
    $('.articles .article').bind('touchstart touchend', function (e) {
        $(this).toggleClass('hover');
    });
}


function PageChange(DivName,DisplayPost) {
    //$("#post-view .current-page").attr("last-scroll-pos", Math.abs($("#post-view .current-page").offset().top - 60));


        if ($(".scroll-disabled").length > 0) {
            jQuery(".page.current-page").animate({ scrollTop: 0 }, 'slow', 'swing');
        }
        else {
            jQuery("#post-container").animate({ scrollTop: 0 }, 'slow', 'swing');
        }
        PageTransitions.nextPage($(DivName));
        $(".page.current-page .wow").css("visibility", "hidden !important");
        $(".post-quick-navigation").fadeOut(1000);
        new WOW().init();
        var wi = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if ($("#post-view").css("visibility") == "hidden" && wi < 1200 && DisplayPost) {
            PageTransitions.PageOuter($("#post-view"), $("#post-list"), 'current-post-part');
            $('.close-post').show('slow');
            $('.cd-nav-trigger').addClass('hide-now');
            $('body').addClass('post-open');
        }
        //setTimeout(activeQuickPostNavigation, 500);
    
}
function ScrollToTop() {
    
    if ($(".scroll-disabled").length > 0) {
        $('.page.current-page').animate({ scrollTop: 0}, 'slow', 'swing');
    }
    else {
        $('#post-container').animate({ scrollTop: 0 }, 'slow', 'swing');
    }
    setTimeout(function () { $(".scroll-top").fadeOut("slow"); }, 500);
}
function resetScrollPosition() { 
//$("#post-view .page").removeAttr("last-scroll-pos");
}